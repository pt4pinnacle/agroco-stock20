export default function Home() {
  return (
    <div style={{ padding: '50px', textAlign: 'center', fontFamily: 'Arial' }}>
      <h1>Welcome to Agroco</h1>
      <p>Your investment platform is now live at <strong>grundlegendweltfischer.com</strong></p>
      <p>
        Go to <a href="/solutions">Solutions</a> to view the Vercel-hosted solutions page.
      </p>
    </div>
  )
}