import { useEffect } from 'react'

export default function Solutions() {
  useEffect(() => {
    window.location.href = 'https://agroco.vercel.app/solutions'
  }, [])
  return <p>Redirecting to Solutions page...</p>
}